import java.awt.*;

public class Lion extends Actor {

    public Lion(Cell loc) {
        this.loc = loc;
        this.colour = Color.RED;
    }

}