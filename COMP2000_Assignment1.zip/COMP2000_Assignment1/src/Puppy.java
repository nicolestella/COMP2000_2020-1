import java.awt.*;

public class Puppy extends Actor {

    public Puppy(Cell loc){
        this.loc = loc;
        this.colour = Color.GREEN;
    }

}