import java.awt.*;

public class Rabbit extends Actor {

    public Rabbit(Cell loc) {
        this.loc = loc;
        this.colour = Color.WHITE;
    }

}