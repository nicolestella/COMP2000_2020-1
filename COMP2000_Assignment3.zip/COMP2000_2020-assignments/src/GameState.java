public interface GameState {
    public void mouseClick(int x, int y, Stage s);
    public void paint(java.awt.Graphics g, Stage s);
}
