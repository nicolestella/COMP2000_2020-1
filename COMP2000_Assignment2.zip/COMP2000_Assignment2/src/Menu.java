public class Menu {
    State state;
    Stage stage;
    int x;
    int y;

    public Menu (State state, Stage stage, int x, int y) {
        this.state = state;
        this.stage = stage;
        this.x = x;
        this.y = y;
    }

    public void createMenu(String type){
        if (type.equals("Fire Menu")) {
            stage.menuOverlay.add(new MenuItem("Fire", x, y, () -> {
                stage.cellOverlay = stage.grid.getRadius(stage.actorInAction.get().loc, stage.actorInAction.get().range,
                        false);
                stage.cellOverlay.remove(stage.actorInAction.get().loc);
                state.setState("SelectingTarget");
                state.setCoordinates(x, y);
            }));
        }

        else if(type.equals("Action Menu")){
                stage.menuOverlay.add(new MenuItem("Oops", x, y, () -> {
                    state.setState("ChoosingActor");
                    state.setCoordinates(x, y);
                }));
                stage.menuOverlay.add(new MenuItem("End Turn", x, y + MenuItem.height, () -> {
                    state.setState("CPUMoving");
                    state.setCoordinates(x, y);
                }));
                stage.menuOverlay.add(new MenuItem("End Game", x, y + MenuItem.height * 2, () -> System.exit(0)));
        }

        else {
            System.out.println("Menu type does not exist.");
        }
    }
}
