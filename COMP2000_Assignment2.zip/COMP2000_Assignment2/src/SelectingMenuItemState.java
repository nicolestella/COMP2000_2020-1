import java.util.*;

public class SelectingMenuItemState extends Observer {
    Stage stage;
    int x;
    int y;
    boolean mouseClicked;

    public SelectingMenuItemState(State state){
        this.state = state;
        this.state.addToList(this);

        stage = state.getStage();
    }

    @Override
    public void updateClicked(boolean a){
        mouseClicked = a;
    }

    @Override
    public void updateCoordinates(int x, int y){
        this.x = x;
        this.y = y;

        if(state.getState().equals("SelectingMenuItem")){
            updateState("SelectingMenuItem");
        }
    }

    @Override
    public void updateState(String currentState){
        if(currentState.equals("SelectingMenuItem") && x>0 && mouseClicked){
            state.clicked(false);
            for(MenuItem mi : stage.menuOverlay){
                if (mi.contains(x,y)){
                    mi.action.run();
                    stage.menuOverlay = new ArrayList<MenuItem>();
                }
            }
        }
    }
}
