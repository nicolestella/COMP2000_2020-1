//This is the abstract class that will be extended by all the observer classes.
public abstract class Observer {
    //It will contain a reference to the Subject class (State.java)
    //and methods to update information so that it can execute actions.
    protected State state;
    public abstract void updateClicked(boolean a);
    public abstract void updateState(String state);
    public abstract void updateCoordinates(int x, int y);
}
