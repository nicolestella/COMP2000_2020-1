import java.util.*;

public class ChoosingActorState extends Observer{
    Stage stage;
    int x;
    int y;
    boolean mouseClicked;
    Menu menu;

    public ChoosingActorState(State state){
        this.state = state;
         //"Subscribe" to the list of observers in State.java
        state.addToList(this);

        stage = state.getStage();
    }

    //set mouseClicked to whatever value is passed into State.java
    @Override
    public void updateClicked(boolean a) {
        mouseClicked = a;
        menu = new Menu(state, stage, x, y);
    }

    //set x and y coordinates to whatever value is passed into State.java
    @Override
    public void updateCoordinates(int x, int y){
        this.x = x;
        this.y = y;

        //After mouse is clicked at the correct spot, check if the state should prompt an action
        if(state.getState().equals("ChoosingActor")){
            updateState("ChoosingActor");
        }
    }

    //Execute the action
    @Override
    public void updateState(String currentState){
        //only execute if mouse has been clicked
        if(currentState.equals("ChoosingActor") && mouseClicked){
            //then immediately set clicked to false to prevent every Observer 
            //object from running all at once
            state.clicked(false);

            stage.actorInAction = Optional.empty();
            for (Actor a : stage.actors) {
                if (a.loc.contains(x, y) && a.isTeamRed() && a.turns > 0) {
                    stage.cellOverlay = stage.grid.getRadius(a.loc, a.moves, true);
                    stage.actorInAction = Optional.of(a);
                    state.setState("SelectingNewLocation");
                    state.setCoordinates(x, y);
                }
            }
            if (stage.actorInAction.isEmpty()) {
                state.setState("SelectingMenuItem");
                state.setCoordinates(x, y);
                menu.createMenu("Action Menu");
            }
        }
    }
}
