import java.util.ArrayList;
import java.util.*;

//This is the subject object containing methods to notify observers of any changes.
//It also contains a Stage object so that the observers can access variables from Stage.
public class State {
    //A list of objects that will be notified of any changes
    private List<Observer> observers = new ArrayList<Observer>();

    private String currentState;
    Stage stage;
    int x;
    int y;
    
    //Stage object is passed in the constructor
    public State(Stage stage){
        this.stage = stage;
    }

    //This method enables observers to access the Stage
    public Stage getStage(){
        return stage;
    }

    //This method enables observers to keep track of the current stage.
    //It also allows the Stage to print the current state.
    public String getState(){
        return currentState;
    }

    //When mouse is clicked, observers will be notified of the new cursor coordinates.
    public void setCoordinates(int x, int y){
        this.x = x;
        this.y = y;

        for(Observer a : observers){
            a.updateCoordinates(x, y);
        }
    }

    //When state changes, observers will be notified of the new state.
    public void setState(String newState){
        currentState = newState;
        
        for(Observer a : observers){
            a.updateState(newState);
        }
    }

    //When mouse is clicked, observers will be notified.
    public void clicked(boolean b){
        for(Observer a : observers){
            a.updateClicked(b);
        }
    }

    //This method allows objects to add themselves to the list.
    public void addToList(Observer newObserver){
        observers.add(newObserver);
    }
}
