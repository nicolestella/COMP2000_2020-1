import java.util.*;

public class SelectingTargetState extends Observer {
    Stage stage;
    int x;
    int y;
    boolean mouseClicked;

    public SelectingTargetState(State state){
        this.state = state;
        this.state.addToList(this);

        stage = state.getStage();
    }

    @Override
    public void updateClicked(boolean a){
        mouseClicked = a;
    }

    @Override
    public void updateCoordinates(int x, int y){
        this.x = x;
        this.y = y;

        if(state.getState().equals("SelectingTarget")){
            updateState("SelectingTarget");
        }
    }

    @Override
    public void updateState(String currentState){
        if(currentState.equals("SelectingTarget") && x>0 && mouseClicked){
            state.clicked(false);
            for(Cell c: stage.cellOverlay){
                if (c.contains(x, y)){
                    Optional<Actor> oa = stage.actorAt(c);
                    if (oa.isPresent()){
                        oa.get().makeRedder(0.1f);
                    }
                }
            }
            stage.cellOverlay = new ArrayList<Cell>();
            state.setState("ChoosingActor");
            state.setCoordinates(x, y);
        }
        mouseClicked = false;
    }
}
