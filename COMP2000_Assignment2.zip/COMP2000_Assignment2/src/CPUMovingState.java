import java.util.*;

public class CPUMovingState extends Observer {
    Stage stage;
    int x;
    int y;
    boolean mouseClicked;

    public CPUMovingState(State state){
        this.state = state;
        //"Subscribe" to the list of observers in State.java
        this.state.addToList(this);

        stage = state.getStage();
    }

    //set mouseClicked to whatever value is passed into State.java
    @Override
    public void updateClicked(boolean a) {
        mouseClicked = a;
        
    }

    //set x and y coordinates to whatever value is passed into State.java
    @Override
    public void updateCoordinates(int x, int y) {
        this.x = x;
        this.y = y;

        //After mouse is clicked at the correct spot, check if the state should prompt an action
        if(state.getState().equals("CPUMoving")){
            updateState("CPUMoving");
        }
    }

    //Execute the action
    @Override
    public void updateState(String currentState) {
        //Unlike the other states/observers, CPUMoving does not need to check whether or not
        //mouse has been clicked because the CPU should move automatically after the player
        //ends their turn.
        if (currentState.equals("CPUMoving")) {
            state.clicked(false);
            for (Actor a : stage.actors) {
                if (!a.isTeamRed()) {
                    List<Cell> possibleLocs = stage.getClearRadius(a.loc, a.moves, true);

                    Cell nextLoc = a.strat.chooseNextLoc(possibleLocs);

                    a.setLocation(nextLoc);
                    System.out.println("CPU Moved");
                }
            }
            state.setState("ChoosingActor");
            state.setCoordinates(x, y);
            for (Actor a : stage.actors) {
                a.turns = 1;
            }
        }
    }
}
