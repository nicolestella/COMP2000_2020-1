import java.util.*;

public class SelectingNewLocationState extends Observer {
    Stage stage;
    int x;
    int y;
    boolean mouseClicked;
    Menu menu;

    public SelectingNewLocationState(State state){
        this.state = state;
        this.state.addToList(this);

        stage = state.getStage();
    }

    @Override
    public void updateClicked(boolean a){
        mouseClicked = a;
        menu = new Menu(state, stage, x, y);
    }

    @Override
    public void updateCoordinates(int x, int y){
        this.x = x;
        this.y = y;
        if(state.getState().equals("SelectingNewLocation")){
            updateState("SelectingNewLocation");
        }

        
    }

    @Override
    public void updateState(String currentState){
        if(currentState.equals("SelectingNewLocation") && x>0 && mouseClicked){
            state.clicked(false);
            Optional<Cell> clicked = Optional.empty();
            for (Cell c : stage.cellOverlay) {
                if (c.contains(x, y)) {
                        clicked = Optional.of(c);
                }
            }
            if (clicked.isPresent() && stage.actorInAction.isPresent()) {
                stage.cellOverlay = new ArrayList<Cell>();
                stage.actorInAction.get().setLocation(clicked.get());
                stage.actorInAction.get().turns--;
                menu.createMenu("Fire Menu");
                state.setState("SelectingMenuItem");
                state.setCoordinates(x, y);
            }
        }
    }
}
